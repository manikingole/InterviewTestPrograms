package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Employee;

@RestController
public class EmployeeController {
	 private List<Employee> employeeData = new ArrayList<>();

	    // Create Employee
	    @PostMapping("/employees")
	    public Employee createEmployee(@RequestBody Employee employee) {
	        employeeData.add(employee);
	        return employee;
	    }

	    // Read Employee Data
	    @GetMapping("/employees")
	    public List<Employee> getAllEmployees() {
	        return employeeData;
	    }

	    @GetMapping("/employees/{id}")
	    public Employee getEmployeeById(@PathVariable int id) {
	        for (Employee employee : employeeData) {
	            if (employee.getId() == id) {
	                return employee;
	            }
	        }
	        return null;
	    }

	    // Update  Employee Data
	    @PutMapping("/employees/{id}")
	    public Employee updateEmployee(@PathVariable int id, @RequestBody Employee updatedEmployee) {
	        for (Employee employee : employeeData) {
	            if (employee.getId() == id) {
	                employee.setFname(updatedEmployee.getFname());
	                employee.setLname(updatedEmployee.getLname());
	                return employee;
	            }
	        }
	        return null;
	    }

	    // Delete Data
	    @DeleteMapping("/employees/{id}")
	    public Employee deleteEmployee(@PathVariable int id) {
	        for (Employee employee : employeeData) {
	            if (employee.getId() == id) {
	                employeeData.remove(employee);
	                return employee;
	            }
	        }
	        return null;
	    }

}
