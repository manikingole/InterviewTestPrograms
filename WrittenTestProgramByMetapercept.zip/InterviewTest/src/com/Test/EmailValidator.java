package com.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator {
	public static boolean isValid(String email) {
		String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

		Pattern pattern = Pattern.compile(emailRegex);
		Matcher matcher = pattern.matcher(email);

		return matcher.matches();

	}

	public static void main(String[] args) {
		String email1 = "test01*gmail.com";
		if (isValid(email1)) {
			System.out.println("valid email id");
		} else {
			System.out.println("invalid email id");
		}
		String email2 = "student01@gmail.com";
		if (isValid(email2)) {
			System.out.println("valid email id");
		} else {
			System.out.println("invalid email id");
		}
	}

}
