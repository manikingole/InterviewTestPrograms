package com.Test;

public class LongestWordFinder {
	 public static String findLongestWord(String input) {
	        String[] words = input.split("\\s+"); // Split the input string into words based on whitespace

	        String longestWord = "";

	        for (String word : words) {
	            if (word.length() > longestWord.length()) {
	                longestWord = word;
	            }
	        }

	        return longestWord;
	    }

	    public static void main(String[] args) {
	        String input1 = "dummy text of the printing and typesetting industry.";
	        String longestWord1 = findLongestWord(input1);
	        System.out.println("Longest Word: " + longestWord1);

	        String input2 = "It is a long established fact that a reader will be distracted by the readable content of " +
	                "a page when looking at its layout. The point of using Lorem Ipsum is that it has a " +
	                "more-or-less normal distributionqqqqqqqqqqqqqqqqqqq of letters, as opposed to using " +
	                "'Content here, content here', making it look like readable English";
	        String longestWord2 = findLongestWord(input2);
	        System.out.println("Longest Word: " + longestWord2);
	    }

}
