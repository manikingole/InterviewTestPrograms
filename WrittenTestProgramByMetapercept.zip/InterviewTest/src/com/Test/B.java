package com.Test;

public class B {
	private int lastDigit1;
	private int lastDigit2;

	public B(A numbers) {
		lastDigit1 = numbers.getNum1() % 10;
		lastDigit2 = numbers.getNum2() % 10;

	}

	public int getLastDigit1() {
		return lastDigit1;
	}

	public int getLastDigit2() {
		return lastDigit2;
	}

}
