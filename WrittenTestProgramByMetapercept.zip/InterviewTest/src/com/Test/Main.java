package com.Test;

public class Main {
	public static void main(String[] args) {
		A numbers = new A(123, 456);
		B digits = new B(numbers);
		C multiplication = new C(digits);

		System.out.println("Last Digits=" + digits.getLastDigit1() + "," + digits.getLastDigit2());
		System.out.println("Multiplication=" + multiplication.getResult());
	}

}
