package com.Test;

public class C {
	private int result;
	
	public C(B digits) {
		result=digits.getLastDigit1()*digits.getLastDigit2();
	}
	public int getResult() {
		return result;
	}

}
